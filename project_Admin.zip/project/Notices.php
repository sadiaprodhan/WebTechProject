<!DOCTYPE html>
<html>
<head>
	<title>Notices </title>
</head>
<body>
<fieldset align="center" style="width:30"  >
			<legend> <h1>Add Notice </h1></legend>
			<table >
			<tr>
			<textarea name= "notice" style= "width:30" placeholder="type notice here..." > </textarea>	<input type= "submit" name= "submit" value="ADD">	</table>
			</fieldset>
			<form>
			<table align='center' border='1' width=100% >
			<tr>
			<td> View Notices</td>
			<td> Verify Notices</td>
			</tr>
			<tr> 
		 <td> Math Exam held tomorrow 3/11/2019 at 4 PM</td>
			<td> English Quiz has been cancelled   <input type= button name= "button" value= "Verify" align="right"> <input type= button name= "Delete" value= "Delete" align= "right"></td>
			</tr>
			<tr> 
			 <td> Physics Quiz Results has been published </td>
			<td> Chemistry New Notes has been uploaded  <input type= button name= "button" value= "Verify" align="right"> <input type= button name= "Delete" value= "Delete" align= "right"></td>
			</tr>
		<tr>
		<td colspan="2" align = "right"> <a href="AdminHome.php" > Go Home  </a></td>
		</tr>
		 </table>
		 </fieldset>
			</body>
			</html>