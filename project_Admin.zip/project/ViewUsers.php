
<html>
<body>
<form>
<table align='center' border='1' width=40%>
<tr>
<td align='center' colspan='6'>View Users </td>

</tr>
<tr>
<td> ID </td>
<td> Name </td>
<td> Email </td>
<td> Gender </td>
<td> Type </td>
<td> Delete User </td>
</tr>
<?php
session_start();
$i=0;
$my= fopen('info.text','r');
 
  while(!feof($my))
{	 {$lin= fgets($my);
$i++;

}}
fclose($my);
$myfile= fopen('info.text','r');
for($a=0; $a<$i -1 ;$a++)
	{$line= fgets($myfile);
	 $data= explode("|",$line);
echo "<tr>";
echo "<td>".$data[0]." </td>";
echo "<td>".$data[2]." </td>";
echo "<td>".$data[3]." </td>";
echo "<td>".$data[4]." </td>";
echo "<td>".$data[5]." </td>";
echo "<td align = center> <input type= button name= delete value= delete> </td>";
  echo "</tr>";	 }
 
?>
<tr>
<td colspan='6' align= "center"><a href="AdminHome.php" > Go Home  </a> </td>
</tr>
</table>
</form>
</body>
</html>
<?php
fclose($myfile);

 
?>