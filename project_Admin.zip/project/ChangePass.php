<?php
session_start();
$oldpass= $newpass= $confirmpass= "";

if(isset($_POST['submit'])){
	$oldpass= $newpass= $confirmpass= "";
$oldpass=$_POST['password'];
		if($oldpass== trim(($_SESSION['password'])))
			
		{$newpass=$_POST['newpassword'];	
		$confirmpass=$_POST['confirmpassword'];

			if($newpass== $confirmpass)
			{
				$_SESSION['password']= $newpass;
				 $name=	$_SESSION['name'];
			 $id= $_SESSION['id'];
			$pass= $_SESSION['password'] ;
			$email= $_SESSION['email'] ;
			
		$usertype=	$_SESSION['type'];
		$gender=	$_SESSION['Gender'] ;

				$myfile= fopen('info.text','a');
	fwrite($myfile,"$id|$pass|$name|$email|$gender|$usertype \n");
	fclose($myfile);
		header('location: AdminProfile.php');
			}	
		else {$confirmpass= "password doesnt match";}
		
		}
		else {$oldpass = "Old Password doesnt match";}
	}

?>

<html>
<body>
<form method="POST">
<table align='center'  width=40%>
<tr>
<td align='center' colspan='2'> Change Password </td>
</tr>
<tr>
<td> Old Password </td>
<td width=50%> <input type="password" name="password" placeholder="Enter old password.. " required/> <?php echo $oldpass; ?> </td>
</tr>
<tr>
<td> New Password</td>
<td width=50% > <input type="password" name="newpassword" placeholder="Enter your new password.. " required/> </td>
</tr>
<tr>
<td> Confirm Password</td>
<td> <input type="password" name="confirmpassword" placeholder="Retype New password.. " required/> <?php echo $confirmpass; ?> </td>
</tr>
<tr>
<td> <input type="submit" name="submit" value="Change"></td>
<td> <a href= "AdminProfile.php"> Back </td>
</tr>
</table>
</form>
</body>
</html>
