<?php
session_start();
?>

<html>
<body>
<form>
<table align='center' border='1' width=40%>
<tr>
<td align='center' colspan='2'>Your Profile </td>
</tr>
<tr>
<td> ID </td>
<td width=50%> <?=$_SESSION['id']?> </td>
</tr>
<tr>
<td> Name </td>
<td width=50% contentEditable="true"> <?=$_SESSION['name']?> </td>
</tr>
<tr>
<td> Email</td>
<td contentEditable="true" width=50%> <?=$_SESSION['email']?> </td>
</tr>
<tr>
<td> Gender </td>
<td width=50% > <?=$_SESSION['Gender']?> </td>
</tr>

<tr>
<td> User Type </td>
<td width=50%> <?=$_SESSION['type']?></td>
</tr>
<tr>
<td> <input type= button name= "Update" value= "Update"></td>
<td width=50%> <a href="ChangePass.php"> Change Password </a> </td>
</tr>

<tr>
<td align='right' colspan='2'> <a href="AdminHome.php"> Go Home </a> </td>
</tr>
</table>
</form>
</body>
</html>