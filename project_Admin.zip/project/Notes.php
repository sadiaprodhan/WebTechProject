<!DOCTYPE html>
<html>
<head>
	<title>Manage Notes  </title>
</head>
<body>
<fieldset align="center" style="width:50" >
			<legend><h1> Notes </h1></legend>
		<table align="center" border="1">
		
		
		<tr>
					<td> <embed src= "FirstOrderLogic.pdf" width= "800px" height = "1200px">  </td>
					<td><input type= button name= "button" value= "Verify" align="right"> <input type= button name= "Delete" value= "Delete" align= "right"></td>
				</tr>
					<tr>
					<td> <embed src= "WPH04.pdf" width= "800px" height = "1200px">  </td>
					<td><input type= button name= "button" value= "Verify" align="right"> <input type= button name= "Delete" value= "Delete" align= "right"></td>
				</tr>
				<tr>
		<td colspan="2" align = "right"> <a href="AdminHome.php" > Go Home  </a></td>
		</tr>
		</table>
		</fieldset>
		</html>
	