<!DOCTYPE html>
<html>
<head>
	<title>Online Classes </title>
</head>
<body>
	<table align="center" border="1" bgcolor="SeaShell">
		<h2 align="center" style="border:2px solid GreenYellow;"> Class 8 Animal Kingdom</h2>
		
		<tr>
			<td><video width='530' height= '240' controls>
<source src='y2mate.com - _class_8_r5OPY-EhuSo_240p.mp4' type='video/mp4'>
Your browser does not support the video tag.
</video>
</td>
<tr>
<td> Nice Video  <input type= button name= "delete" value= "delete" align="right"> <input type= button name= "Warning" value= "Send Warning" align= "right"> </td>

</tr>
<tr>
 <td><input type="text" name="comment" placeholder="Enter your comment.." > <input type="submit" name="submit" value="Comment"></td>
</tr>
 	</table>
<table align="center" border="1" bgcolor="SeaShell">
		<h2 align="center" style="border:2px solid GreenYellow;"> class 12 physics</h2>
		
		<tr>
			<td><video width='530' height= '240'  controls >
<source src='y2mate.com - _hsc_DHAr6NT6d98_240p.mp4' type='video/mp4'>
Your browser does not support the video tag.
</video>
</td>
<tr>
<td> Thankyou learnt a lot  <input type= button name= "delete" value= "delete" align="right"> <input type= button name= "Warning" value= "Send Warning" align= "right"> </td>

</tr>
<tr>
 <td><input type="text" name="comment" placeholder="Enter your comment.." > <input type="submit" name="submit" value="Comment"></td>
</tr>
<tr>
		<td colspan="2" align = "right"> <a href="AdminHome.php" > Go Home  </a></td>
		</tr>
		
 	</table>

</body>
</html>