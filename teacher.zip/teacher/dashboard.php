<!DOCTYPE html>
<head>

<title>Teachers portal</title>

<link rel="stylesheet" type="text/css" href="site.css">.
</head>


<body>

<h1>Welcome to Teachers Portal<h1>
<img src="img/logout.png" alt="Logout"  width="100px" height="100px" align="right">

<br>

<p>Choose any option below</p>


<img src="img/abc.png" alt="Courses" style="width:100px;height:100px;"> 
<img src="img/file.png" alt="Exam" style="width:100px;height:100px;">
<img src="img/student.png" alt="Student" style="width:100px;height:100px;">



<img src="img/logout.png" alt="Logout" style="width:100px;height:100px;align=bottom;">


<!-- Add more -->


</body>